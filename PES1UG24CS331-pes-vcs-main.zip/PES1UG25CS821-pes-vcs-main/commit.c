// commit.c — Commit creation and history traversal
//
// Commit object format (stored as text, one field per line):
//
//   tree <64-char-hex-hash>
//   parent <64-char-hex-hash>        ← omitted for the first commit
//   author <name> <unix-timestamp>
//   committer <name> <unix-timestamp>
//
//   <commit message>
//
// Note: there is a blank line between the headers and the message.
//
// PROVIDED functions: commit_parse, commit_serialize, commit_walk, head_read, head_update
// TODO functions:     commit_create

#include "commit.h"
#include "index.h"
#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

// Forward declarations (implemented in object.c)
int object_write(ObjectType type, const void *data, size_t len, ObjectID *id_out);
int object_read(const ObjectID *id, ObjectType *type_out, void **data_out, size_t *len_out);

// ─── PROVIDED ────────────────────────────────────────────────────────────────

// Parse raw commit data into a Commit struct.
int commit_parse(const void *data, size_t len, Commit *commit_out)
{
    const char *start = (const char *)data;
    const char *end = start + len;
    const char *p = start;
    char hex[HASH_HEX_SIZE + 1];

    if (sscanf(p, "tree %64s\n", hex) != 1)
        return -1;
    if (hex_to_hash(hex, &commit_out->tree) != 0)
        return -1;
    p = strchr(p, '\n');
    if (!p)
        return -1;
    p++;

    if (strncmp(p, "parent ", 7) == 0)
    {
        if (sscanf(p, "parent %64s\n", hex) != 1)
            return -1;
        if (hex_to_hash(hex, &commit_out->parent) != 0)
            return -1;
        commit_out->has_parent = 1;
        p = strchr(p, '\n');
        if (!p)
            return -1;
        p++;
    }
    else
    {
        commit_out->has_parent = 0;
    }

    char author_buf[256];
    uint64_t ts;

    if (sscanf(p, "author %255[^\n]\n", author_buf) != 1)
        return -1;
    char *last_space = strrchr(author_buf, ' ');
    if (!last_space)
        return -1;
    ts = (uint64_t)strtoull(last_space + 1, NULL, 10);
    *last_space = '\0';

    snprintf(commit_out->author, sizeof(commit_out->author), "%s", author_buf);
    commit_out->timestamp = ts;

    p = strchr(p, '\n');
    if (!p)
        return -1;
    p++;
    p = strchr(p, '\n');
    if (!p)
        return -1;
    p++;
    p = strchr(p, '\n');
    if (!p)
        return -1;
    p++;

    size_t msg_len = (size_t)(end - p);
    if (msg_len >= sizeof(commit_out->message))
        msg_len = sizeof(commit_out->message) - 1;

    memcpy(commit_out->message, p, msg_len);
    commit_out->message[msg_len] = '\0';

    return 0;
}

// Serialize a Commit struct to the text format.
// Caller must free(*data_out).
int commit_serialize(const Commit *commit, void **data_out, size_t *len_out)
{
    char tree_hex[HASH_HEX_SIZE + 1];
    char parent_hex[HASH_HEX_SIZE + 1];
    hash_to_hex(&commit->tree, tree_hex);

    char buf[8192];
    int n = 0;
    n += snprintf(buf + n, sizeof(buf) - n, "tree %s\n", tree_hex);
    if (commit->has_parent)
    {
        hash_to_hex(&commit->parent, parent_hex);
        n += snprintf(buf + n, sizeof(buf) - n, "parent %s\n", parent_hex);
    }
    n += snprintf(buf + n, sizeof(buf) - n,
                  "author %s %" PRIu64 "\n"
                  "committer %s %" PRIu64 "\n"
                  "\n"
                  "%s",
                  commit->author, commit->timestamp,
                  commit->author, commit->timestamp,
                  commit->message);

    *data_out = malloc(n + 1);
    if (!*data_out)
        return -1;
    memcpy(*data_out, buf, n + 1);
    *len_out = (size_t)n;
    return 0;
}

// Walk commit history from HEAD to the root.
int commit_walk(commit_walk_fn callback, void *ctx)
{
    ObjectID id;
    if (head_read(&id) != 0)
        return -1;

    while (1)
    {
        ObjectType type;
        void *raw;
        size_t raw_len;
        if (object_read(&id, &type, &raw, &raw_len) != 0)
            return -1;

        Commit c;
        int rc = commit_parse(raw, raw_len, &c);
        free(raw);
        if (rc != 0)
            return -1;

        callback(&id, &c, ctx);

        if (!c.has_parent)
            break;
        id = c.parent;
    }
    return 0;
}

// Read the current HEAD commit hash.
int head_read(ObjectID *id_out)
{
    FILE *f = fopen(HEAD_FILE, "r");
    if (!f)
        return -1;
    char line[512];
    if (!fgets(line, sizeof(line), f))
    {
        fclose(f);
        return -1;
    }
    fclose(f);
    line[strcspn(line, "\r\n")] = '\0'; // strip newline

    char ref_path[512];
    if (strncmp(line, "ref: ", 5) == 0)
    {
        snprintf(ref_path, sizeof(ref_path), "%s/%s", PES_DIR, line + 5);
        f = fopen(ref_path, "r");
        if (!f)
            return -1; // Branch exists but has no commits yet
        if (!fgets(line, sizeof(line), f))
        {
            fclose(f);
            return -1;
        }
        fclose(f);
        line[strcspn(line, "\r\n")] = '\0';
    }
    return hex_to_hash(line, id_out);
}

// Update the current branch ref to point to a new commit atomically.
int head_update(const ObjectID *new_commit)
{
    FILE *f = fopen(HEAD_FILE, "r");
    if (!f)
        return -1;
    char line[512];
    if (!fgets(line, sizeof(line), f))
    {
        fclose(f);
        return -1;
    }
    fclose(f);
    line[strcspn(line, "\r\n")] = '\0';

    char target_path[520];
    if (strncmp(line, "ref: ", 5) == 0)
    {
        snprintf(target_path, sizeof(target_path), "%s/%s", PES_DIR, line + 5);
    }
    else
    {
        snprintf(target_path, sizeof(target_path), "%s", HEAD_FILE); // Detached HEAD
    }

    char tmp_path[528];
    snprintf(tmp_path, sizeof(tmp_path), "%s.tmp", target_path);

    f = fopen(tmp_path, "w");
    if (!f)
        return -1;

    char hex[HASH_HEX_SIZE + 1];
    hash_to_hex(new_commit, hex);
    fprintf(f, "%s\n", hex);

    fflush(f);
    fsync(fileno(f));
    fclose(f);

    return rename(tmp_path, target_path);
}

// ─── TODO: Implement these ───────────────────────────────────────────────────

// Create a new commit from the current staging area.
//
// HINTS - Useful functions to call:
//   - tree_from_index   : writes the directory tree and gets the root hash
//   - head_read         : gets the parent commit hash (if any)
//   - pes_author        : retrieves the author name string (from pes.h)
//   - time(NULL)        : gets the current unix timestamp
//   - commit_serialize  : converts the filled Commit struct to a text buffer
//   - object_write      : saves the serialized text as OBJ_COMMIT
//   - head_update       : moves the branch pointer to your new commit
//
// Returns 0 on success, -1 on error.
int commit_create(const char *message, ObjectID *commit_id_out)
{
    // 🔹 STEP 1: Build tree
    ObjectID tree_id;
    if (tree_from_index(&tree_id) != 0)
        return -1;

    // 🔹 STEP 2: Read HEAD (parent)
    ObjectID parent_id;
    int has_parent = (head_read(&parent_id) == 0);

    // 🔹 STEP 3: Fill commit struct
    Commit commit;
    memset(&commit, 0, sizeof(commit));

    commit.tree = tree_id;
    commit.has_parent = has_parent;

    if (has_parent)
        commit.parent = parent_id;

    snprintf(commit.author, sizeof(commit.author), "%s", pes_author());
    commit.timestamp = (uint64_t)time(NULL);
    snprintf(commit.message, sizeof(commit.message), "%s", message);

    // 🔹 STEP 4: Serialize
    void *data;
    size_t len;
    if (commit_serialize(&commit, &data, &len) != 0)
        return -1;

    // 🔹 STEP 5: Store commit object
    if (object_write(OBJ_COMMIT, data, len, commit_id_out) != 0)
    {
        free(data);
        return -1;
    }

    free(data);

    // 🔹 STEP 6: Ensure branch file exists (FIRST COMMIT FIX)
    FILE *f = fopen(HEAD_FILE, "r");
    if (!f) return -1;

    char line[512];
    if (!fgets(line, sizeof(line), f)) {
        fclose(f);
        return -1;
    }
    fclose(f);

    line[strcspn(line, "\r\n")] = '\0';

    if (strncmp(line, "ref: ", 5) == 0)
    {
        char ref_path[512];
        snprintf(ref_path, sizeof(ref_path), "%s/%s", PES_DIR, line + 5);

        // create directory if needed
        mkdir(".pes/refs", 0755);
        mkdir(".pes/refs/heads", 0755);

        FILE *rf = fopen(ref_path, "a");  // create file if not exists
        if (rf)
            fclose(rf);
    }

    // 🔹 STEP 7: Update HEAD
    if (head_update(commit_id_out) != 0)
        return -1;

    return 0;
}
