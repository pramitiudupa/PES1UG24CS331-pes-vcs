
#include "pes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/evp.h>

// ─── PROVIDED ────────────────────────────────────────────────────────────────

void hash_to_hex(const ObjectID *id, char *hex_out) {
    for (int i = 0; i < HASH_SIZE; i++) {
        sprintf(hex_out + i * 2, "%02x", id->hash[i]);
    }
    hex_out[HASH_HEX_SIZE] = '\0';
}

int hex_to_hash(const char *hex, ObjectID *id_out) {
    if (strlen(hex) < HASH_HEX_SIZE) return -1;
    for (int i = 0; i < HASH_SIZE; i++) {
        unsigned int byte;
        if (sscanf(hex + i * 2, "%2x", &byte) != 1) return -1;
        id_out->hash[i] = (uint8_t)byte;
    }
    return 0;
}

void compute_hash(const void *data, size_t len, ObjectID *id_out) {
    unsigned int hash_len;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), NULL);
    EVP_DigestUpdate(ctx, data, len);
    EVP_DigestFinal_ex(ctx, id_out->hash, &hash_len);
    EVP_MD_CTX_free(ctx);
}

// Get the filesystem path where an object should be stored.
// Format: .pes/objects/XX/YYYYYYYY...
// The first 2 hex chars form the shard directory; the rest is the filename.
void object_path(const ObjectID *id, char *path_out, size_t path_size) {
    char hex[HASH_HEX_SIZE + 1];
    hash_to_hex(id, hex);
    snprintf(path_out, path_size, "%s/%.2s/%s", OBJECTS_DIR, hex, hex + 2);
}

int object_exists(const ObjectID *id) {
    char path[512];
    object_path(id, path, sizeof(path));
    return access(path, F_OK) == 0;
}

// ─── TODO: Implement these ──────────────────────────────────────────────────

// Write an object to the store.
//
// Object format on disk:
//   "<type> <size>\0<data>"
//   where <type> is "blob", "tree", or "commit"
//   and <size> is the decimal string of the data length
//
// Steps:
//   1. Build the full object: header ("blob 16\0") + data
//   2. Compute SHA-256 hash of the FULL object (header + data)
//   3. Check if object already exists (deduplication) — if so, just return success
//   4. Create shard directory (.pes/objects/XX/) if it doesn't exist
//   5. Write to a temporary file in the same shard directory
//   6. fsync() the temporary file to ensure data reaches disk
//   7. rename() the temp file to the final path (atomic on POSIX)
//   8. Open and fsync() the shard directory to persist the rename
//   9. Store the computed hash in *id_out

// HINTS - Useful syscalls and functions for this phase:
//   - sprintf / snprintf : formatting the header string
//   - compute_hash       : hashing the combined header + data
//   - object_exists      : checking for deduplication
//   - mkdir              : creating the shard directory (use mode 0755)
//   - open, write, close : creating and writing to the temp file
//                          (Use O_CREAT | O_WRONLY | O_TRUNC, mode 0644)
//   - fsync              : flushing the file descriptor to disk
//   - rename             : atomically moving the temp file to the final path
//

//
// Returns 0 on success, -1 on error.
int object_write(ObjectType type, const void *data, size_t len, ObjectID *id_out) {
    (void)type; // Phase 1 assumes blob

    // STEP 1: Build header
    char header[64];
    int header_len = snprintf(header, sizeof(header), "blob %zu", len) + 1;

    size_t total_size = header_len + len;

    char *full_object = malloc(total_size);
    if (!full_object) return -1;

    memcpy(full_object, header, header_len);
    memcpy(full_object + header_len, data, len);

    // STEP 2: Compute hash
    compute_hash(full_object, total_size, id_out);

    // STEP 3: Deduplication
    if (object_exists(id_out)) {
        free(full_object);
        return 0;
    }

    // STEP 4: Get path
    char path[512];
    object_path(id_out, path, sizeof(path));

    // Extract directory
    char dir[512];
    strncpy(dir, path, sizeof(dir));
    char *slash = strrchr(dir, '/');
    if (!slash) {
        free(full_object);
        return -1;
    }
    *slash = '\0';

    // STEP 5: Create directory
    mkdir(dir, 0755);

    // STEP 6: Temp file
    char temp_path[512];
    if (snprintf(temp_path, sizeof(temp_path), "%s/tmpXXXXXX", dir) >= (int)sizeof(temp_path)) {
        free(full_object);
        return -1;
    }

    int fd = mkstemp(temp_path);
    if (fd < 0) {
        free(full_object);
        return -1;
    }

    // STEP 7: Write
    if (write(fd, full_object, total_size) != (ssize_t)total_size) {
        close(fd);
        free(full_object);
        return -1;
    }

    // STEP 8: fsync file
    fsync(fd);
    close(fd);

    // STEP 9: Rename
    if (rename(temp_path, path) != 0) {
        free(full_object);
        return -1;
    }

    // STEP 10: fsync directory
    int dir_fd = open(dir, O_DIRECTORY);
    if (dir_fd >= 0) {
        fsync(dir_fd);
        close(dir_fd);
    }

    free(full_object);
    return 0;
}
// Read an object from the store.
//
// Steps:
//   1. Build the file path from the hash using object_path()
//   2. Open and read the entire file
//   3. Parse the header to extract the type string and size
//   4. Verify integrity: recompute the SHA-256 of the file contents
//      and compare to the expected hash (from *id). Return -1 if mismatch.
//   5. Set *type_out to the parsed ObjectType
//   6. Allocate a buffer, copy the data portion (after the \0), set *data_out and *len_out
//
// HINTS - Useful syscalls and functions for this phase:
//   - object_path        : getting the target file path
//   - fopen, fread, fseek: reading the file into memory
//   - memchr             : safely finding the '\0' separating header and data
//   - strncmp            : parsing the type string ("blob", "tree", "commit")
//   - compute_hash       : re-hashing the read data for integrity verification
//   - memcmp             : comparing the computed hash against the requested hash
//   - malloc, memcpy     : allocating and returning the extracted data
//// The caller is responsible for calling free(*data_out).
// Returns 0 on success, -1 on error (file not found, corrupt, etc.).
int object_read(const ObjectID *id, ObjectType *type_out, void **data_out, size_t *len_out) {

    // STEP 1: Path
    char path[512];
    object_path(id, path, sizeof(path));

    // STEP 2: Open file
    FILE *fp = fopen(path, "rb");
    if (!fp) return -1;

    // STEP 3: File size
    fseek(fp, 0, SEEK_END);
    size_t file_size = ftell(fp);
    rewind(fp);

    // STEP 4: Read file
    char *buffer = malloc(file_size);
    if (!buffer) {
        fclose(fp);
        return -1;
    }

    if (fread(buffer, 1, file_size, fp) != file_size) {
        free(buffer);
        fclose(fp);
        return -1;
    }
    fclose(fp);

    // STEP 5: Verify hash
    ObjectID computed_id;
    compute_hash(buffer, file_size, &computed_id);

    if (memcmp(id->hash, computed_id.hash, HASH_SIZE) != 0) {
        free(buffer);
        return -1;
    }

    // STEP 6: Find '\0'
    char *null_pos = memchr(buffer, '\0', file_size);
    if (!null_pos) {
        free(buffer);
        return -1;
    }

    // STEP 7: Parse type
    if (strncmp(buffer, "blob ", 5) == 0) {
        *type_out = OBJ_BLOB;
    } else if (strncmp(buffer, "tree ", 5) == 0) {
        *type_out = OBJ_TREE;
    } else if (strncmp(buffer, "commit ", 7) == 0) {
        *type_out = OBJ_COMMIT;
    } else {
        free(buffer);
        return -1;
    }

    // STEP 8: Parse size
    size_t data_size;
    if (sscanf(buffer + 5, "%zu", &data_size) != 1) {
        free(buffer);
        return -1;
    }

    // STEP 9: Extract data
    char *data_start = null_pos + 1;

    if ((size_t)(data_start - buffer + data_size) > file_size) {
        free(buffer);
        return -1;
    }

    void *data = malloc(data_size);
    if (!data) {
        free(buffer);
        return -1;
    }

    memcpy(data, data_start, data_size);

    *data_out = data;
    *len_out = data_size;

    free(buffer);
    return 0;
}
